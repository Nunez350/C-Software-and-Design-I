


extern void drawX(int length);// this function take a length parameter as argument and uses that to make an X accordingly
extern void drawRect(int length, int height);//this function takes length and height argument parameters and uses them to print out a rectangle accordingly
extern void drawPix(char c);//this function takes a character argument and prints out pixel accordingly






