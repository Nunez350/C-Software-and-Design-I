#include <iostream>
#include "lab9.h"
using namespace std;


void drawPix(char c) {  
  cout << c<<endl;
}
